package com.niit.efashion.dao;

import org.springframework.stereotype.Repository;

@Repository
public class UserDAO {

	public boolean isValidUser(String userName, String password) {
		if (userName.equals("niit") && password.equals("niit@123")) {
			return true;
		} 
		else 
		{
			return false;
		}
	}

}
