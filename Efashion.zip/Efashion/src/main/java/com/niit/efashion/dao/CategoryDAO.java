package com.niit.efashion.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.efashion.bean.Category;

@Repository
public class CategoryDAO {
	
	public List<Category> getAllCategories(){
		
		List<Category> list = new ArrayList<Category>();
		Category c1= new Category();
		c1.setId("CAT_MEN");
		c1.setName("CLOTHES");
		c1.setDescription("This is Men's Clothes Section");
		list.add(c1);
		
		
		c1= new Category();
		c1.setId("CAT_WOMEN");
		c1.setName("CLOTHES");
		c1.setDescription("This is Women's Clothes Section");
		list.add(c1);
		
		
		c1= new Category();
		c1.setId("CAT_CHILD");
		c1.setName("CLOTHES");
		c1.setDescription("This is Kids Clothes Section");
		list.add(c1);
		return list;
		
		
	}

}
