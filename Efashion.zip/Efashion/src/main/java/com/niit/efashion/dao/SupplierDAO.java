package com.niit.efashion.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.efashion.bean.Supplier;

@Repository
public class SupplierDAO {
	
	public List<Supplier> getAllSuppliers(){
		
		List<Supplier> list = new ArrayList<Supplier>();
		Supplier s1= new Supplier();
		s1.setId("S001");
		s1.setName("Pantaloons");
		s1.setAddress("Mumbai");
		list.add(s1);
		
		
		s1= new Supplier();
		s1.setId("S002");
		s1.setName("Big Bazaar");
		s1.setAddress("Bangalore");
		list.add(s1);
		
		
		s1= new Supplier();
		s1.setId("S003");
		s1.setName("Central");
		s1.setAddress("New Delhi");
		list.add(s1);
		return list;
		
		
	}

}

