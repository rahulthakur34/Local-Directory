package com.niit.efashion.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.efashion.bean.Category;
import com.niit.efashion.dao.CategoryDAO;

@Controller
public class CategoryController 
{
	@Autowired
	CategoryDAO categoryDAO;

	@RequestMapping("/getAllCategories")
	public ModelAndView getAllCategories() {
		System.out.println("getAllCategories");
		
		List <Category> categoryList = categoryDAO.getAllCategories();
		
		ModelAndView mv = new ModelAndView("/categorylist");
		mv.addObject("categoryList", categoryList);
		
		return mv;

	}
}