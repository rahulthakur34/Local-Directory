package com.niit.efashion.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.efashion.bean.Product;

@Repository
public class ProductDAO 
{
	public List<Product> getAllProducts()
	{
		
		List<Product> list = new ArrayList<Product>();
		
		Product p1= new Product();
		p1.setId("PRO_MEN");
		p1.setName("Trousers");
		p1.setCategoryname("Men");
		p1.setDescription("This is Men's Clothes Section");
		p1.setSuppliername("Peter England");
		p1.setPrice("2500");
		p1.setStock("150");
		list.add(p1);
		
		p1= new Product();
		p1.setId("PRO_WOMEN");
		p1.setName("Saree");
		p1.setCategoryname("Women");
		p1.setDescription("This is Women's Clothes Section");
		p1.setSuppliername("Bodyline");
		p1.setPrice("1899");
		p1.setStock("100");
		list.add(p1);
		
		p1= new Product();
		p1.setId("PRO_KIDS");
		p1.setName("T-Shirt");
		p1.setCategoryname("Kids");
		p1.setDescription("This is Men's Clothes Section");
		p1.setSuppliername("Giny & Jony");
		p1.setPrice("785");
		p1.setStock("75");
		list.add(p1);
		
		return list;
	}
}

