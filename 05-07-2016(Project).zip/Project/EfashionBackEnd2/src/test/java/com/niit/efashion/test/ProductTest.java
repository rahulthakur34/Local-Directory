package com.niit.efashion.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.efashion.dao.ProductDAO;
import com.niit.efashion.model.Category;
import com.niit.efashion.model.Product;
import com.niit.efashion.model.Supplier;

public class ProductTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.efashion");
		context.refresh();
		
		Category category=(Category) context.getBean("category");
		
		category.setCategoryId("C002");
		
		Supplier supplier=(Supplier)context.getBean("supplier");
		
		supplier.setSupplierId("S001");
		
		ProductDAO productDAO=(ProductDAO) context.getBean("productDAO");
		Product product=(Product)context.getBean("product");
		
		product.setProductId("P001");
		product.setProductName("Samsung Galaxy J7");
		product.setDescription("Samsung Mobile");
		product.setPrice("14000.00");
		product.setCategory(category);
		product.setSupplier(supplier);
		
		productDAO.saveOrUpdate(product);
	}

}
