package com.niit.efashion.controller;

import org.apache.tomcat.jni.Address;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.niit.efashion.dao.AddressDetailsDAO;
import com.niit.efashion.dao.CartDAO;
import com.niit.efashion.dao.PaymentDAO;
import com.niit.efashion.model.AddressDetails;
import com.niit.efashion.model.Cart;
import com.niit.efashion.model.Payment;

@Controller
public class PaymentController {

	@Autowired
	PaymentDAO paymentDAO;

	@Autowired
	Cart cart;

	@Autowired
	CartDAO cartDAO;

	@Autowired
	AddressDetailsDAO addressDetailsDAO;

	@Autowired
	AddressDetails addressDetails;

	@RequestMapping("/gotopayment")
	public String goToPayment() {

		return "payment";

	}

	@RequestMapping("/makepayment")
	public String makePayment(@RequestParam("cartid") int id, @RequestParam("account") String account,
			@RequestParam("card") String card, @RequestParam("name") String name, @RequestParam("expiry") String expiry,
			@RequestParam("pin") String pin, @RequestParam("type") String type, Model model) {
		System.out.println(id);
		Cart cart = cartDAO.get(id);
		int total = cart.getTotal();
		Payment payment = paymentDAO.get(account);
		int balance = payment.getBalance();

		if (balance > total) {

			if (card.equals(payment.getCard_number()) && name.equals(payment.getAccount_name())
					&& expiry.equals(payment.getExpiry_date()) && pin.equals(payment.getPin())
					&& type.equals(payment.getType())) {
                cart.setStatus('Y');
                cartDAO.saveOrUpdate(cart);
				payment.setBalance(balance - total);
				paymentDAO.saveOrUpdate(payment);
			}
			model.addAttribute("account", payment);
			return "orderConfirmation";
		}

		else {
			return "transactionFailed";
		}

	}
}
