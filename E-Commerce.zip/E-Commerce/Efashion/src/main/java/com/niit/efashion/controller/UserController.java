package com.niit.efashion.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.efashion.dao.CategoryDAO;
import com.niit.efashion.dao.UserDAO;
import com.niit.efashion.model.Category;
import com.niit.efashion.model.User;

@Controller
public class UserController {

	@Autowired
	UserDAO userDAO;

	@Autowired
	User user;

	@Autowired
	CategoryDAO categoryDAO;

	@RequestMapping(value = "/Home", method = RequestMethod.GET)
	public ModelAndView printWelcome(Principal principal, HttpServletRequest request) {
		ModelAndView mv;
		String name = principal.getName();
		System.out.println(name);
		if (request.isUserInRole("ROLE_ADMIN")) {
			System.out.println(request.isUserInRole("ROLE_ADMIN"));
			System.out.println("Admin page");
			mv=new ModelAndView("welcomeadmin");
			mv.addObject("isAdminpage", true);
			mv.addObject("username", name);
			return mv;
		} 
		else {
			System.out.println(request.isUserInRole("ROLE_USER"));
			System.out.println("user page");
			mv=new ModelAndView("welcomeuser");
			mv.addObject("username", name);
			mv.addObject("category", new Category());
			mv.addObject("categoryList", this.categoryDAO.list());
			mv.addObject("isUserHome", true);
			return mv;
		}
	}
	
	@RequestMapping("/error")
	public String getError(Model model,HttpServletRequest request)
	{
		String name=request.getParameter("username");
		model.addAttribute("username", name);
		return "error";
	}
}
