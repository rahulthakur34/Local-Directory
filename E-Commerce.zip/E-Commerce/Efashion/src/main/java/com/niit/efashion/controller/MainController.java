package com.niit.efashion.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.efashion.dao.CategoryDAO;
import com.niit.efashion.dao.UserDAO;
import com.niit.efashion.model.Category;
import com.niit.efashion.model.User;

@Controller
public class MainController {

	@Autowired
	CategoryDAO categoryDAO;

	@Autowired
	UserDAO userDAO;

	@Autowired
	User user;

	@RequestMapping("/")
	public ModelAndView getLanding() {
		ModelAndView mv = new ModelAndView("index");
		return mv;
	}

	@RequestMapping("/gotolanding")
	public String getLandingPage(Model model) {
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", this.categoryDAO.list());
		return "landingpage";
	}

	@RequestMapping("/gotologin")
	public String getLoginPage(@RequestParam(value = "error", required = false) String error,
			@RequestParam(value = "logout", required = false) String logout, Model model) {
		if (error != null) {
			model.addAttribute("error", "Invalid username and password!");
		}
		if (logout != null) {
			model.addAttribute("logout", "You have been logged out successfully.");
		}
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", this.categoryDAO.list());
		return "login";

	}

	@RequestMapping("/gotoregistration")
	public String getRegistrationPage(Model model) {
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", this.categoryDAO.list());
		return "registration";
	}

	@RequestMapping("/gotoaboutus")
	public String getAboutUsPage(Model model) {
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", this.categoryDAO.list());
		return "aboutus";
	}

	@RequestMapping("/gotocontactus")
	public String getContactUsPage(Model model) {
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", this.categoryDAO.list());
		return "contactus";
	}

	@RequestMapping("/register")
	public ModelAndView registerUser(@RequestParam("password") String password,
			@RequestParam("repassword") String repassword, @RequestParam("name") String name,
			@RequestParam("username") String username, @RequestParam("email") String email,
			@RequestParam("mobile") String mobile) {
		ModelAndView mv;
		String message = null;
		if (password.equals(repassword)) {
			user.setUsername(username);
			user.setPassword(password);
			user.setName(name);
			user.setEmail(email);
			user.setMobile(mobile);
			if (username.contains("niit")) {
				user.setEnabled(true);
				user.setRole("ROLE_ADMIN");
			} else {
				user.setEnabled(true);
				user.setRole("ROLE_USER");
			}
			userDAO.saveorupdate(user);
			mv = new ModelAndView("login");
		} else {
			message = "Passwords does not match";
			mv = new ModelAndView("registration");
		}
		mv.addObject("message", message);
		return mv;
	}

}
