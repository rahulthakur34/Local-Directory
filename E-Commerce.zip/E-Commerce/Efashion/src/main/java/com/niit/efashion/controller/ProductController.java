package com.niit.efashion.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import com.niit.efashion.dao.CategoryDAO;
import com.niit.efashion.dao.ProductDAO;
import com.niit.efashion.dao.SupplierDAO;
import com.niit.efashion.model.Category;
import com.niit.efashion.model.Product;
import com.niit.efashion.model.Supplier;

@Controller
public class ProductController {

	@Autowired
	ProductDAO productDAO;

	@Autowired
	CategoryDAO categoryDAO;

	@Autowired
	SupplierDAO supplierDAO;

	@Autowired
	Product product;
	
	private Path path;

	@RequestMapping(value = "/getAllProducts", method = RequestMethod.GET)
	public String listProducts(Model model) {
		model.addAttribute("product", new Product());
		model.addAttribute("category", new Category());
		model.addAttribute("supplier", new Supplier());
		model.addAttribute("productList", this.productDAO.list());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("supplierList", this.supplierDAO.list());
		model.addAttribute("isProductClicked", true);
		return "welcomeadmin";
	}

	@RequestMapping(value = "/product/add", method = RequestMethod.POST)
	public String addProduct(@ModelAttribute("product") Product product,HttpSession session) {

		Category category = categoryDAO.getByName(product.getCategory().getName());
		categoryDAO.saveorupdate(category);

		Supplier supplier = supplierDAO.getByName(product.getSupplier().getName());
		supplierDAO.saveorupdate(supplier);

		product.setCategory(category);
		product.setSupplier(supplier);

		product.setCategory_id(category.getCategoryId());
		product.setSupplier_id(supplier.getSupplierId());

		try {
			MultipartFile filea = product.getImage();

			InputStream inputStream = null;
			OutputStream outputStream = null;
			if (filea.getSize() > 0) {
			inputStream = filea.getInputStream();
			outputStream = new FileOutputStream("D:\\productimages\\"+product.getProductId()+".jpg");
			System.out.println("====22=========");
			System.out.println(filea.getOriginalFilename());
			System.out.println("=============");
			int readBytes = 0;
			byte[] buffer = new byte[8192];
			while ((readBytes = inputStream.read(buffer, 0, 8192)) != -1) {
			System.out.println("===ddd=======");
			outputStream.write(buffer, 0, readBytes);
			}
			outputStream.close();
			inputStream.close();
			session.setAttribute("uploadFile", "D:\\productimages\\"+product.getProductId()+".jpg");
			System.out.println("Image Inserted");
		} 
		}
		catch (Exception e) {
			System.out.println("Image Not inserted");
		}

		productDAO.saveorupdate(product);

		return "redirect:/getAllProducts";

	}

	@RequestMapping("product/remove/{id}")
	public String removeProduct(@PathVariable("id") String id, ModelMap model) throws Exception {

		try {
			productDAO.delete(id);
			model.addAttribute("message", "Successfully Added");
		} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			e.printStackTrace();
		}

		return "redirect:/getAllProducts";
	}

	@RequestMapping("product/edit/{id}")
	public String editProduct(@PathVariable("id") String id, Model model) {
		System.out.println("editProduct");
		model.addAttribute("product", this.productDAO.get(id));
		model.addAttribute("listProducts", this.productDAO.list());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("supplierList", this.supplierDAO.list());
		model.addAttribute("isProductClicked", true);
		return "welcomeadmin";
	}

	@RequestMapping("product/get/{id}")
	public String getSelectedProduct(@PathVariable("id") String productId, Principal principal, Model model) {
		String name = principal.getName();
		model.addAttribute("username", name);
		product = productDAO.get(productId);
		return "redirect:/userpage";
	}

	@RequestMapping("/userpage")
	public String getHomePage(Model model, Principal principal) {
		String name = principal.getName();
		String id = product.getProductId();
		model.addAttribute("id", id);
		model.addAttribute("username", name);
		model.addAttribute("uploadFile", "D:\\productimages\\"+product.getProductId()+".jpg");
		model.addAttribute("selectedProduct", this.productDAO.get(id));
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", this.categoryDAO.list());
		return "welcomeuser";
	}

	@RequestMapping("/userhomepage")
	public String getUserPage(Model model, Principal principal) {
		String name = principal.getName();
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("isUserHome", true);
		model.addAttribute("username", name);
		return "welcomeuser";
	}

}
