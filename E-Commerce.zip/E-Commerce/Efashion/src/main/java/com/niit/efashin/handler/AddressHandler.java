package com.niit.efashin.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.niit.efashion.dao.AddressDetailsDAO;
import com.niit.efashion.model.AddressDetails;

@Component
public class AddressHandler {

	@Autowired
	AddressDetailsDAO addressDetailsDAO;
	
	public String saveAddress(AddressDetails addressDetails)
	{
		String status=null;
		try 
		{
			int cart=addressDetails.getCartId();
			String house=addressDetails.getHouseNo();
			String locality=addressDetails.getLocality();
			String city=addressDetails.getCity();
			String district=addressDetails.getDistrict();
			String state=addressDetails.getState();
			String pincode=addressDetails.getPincode();
			
			AddressDetails address=new AddressDetails();
			address.setCartId(cart);
			address.setHouseNo(house);
			address.setLocality(locality);
			address.setCity(city);
			address.setDistrict(district);
			address.setState(state);
			address.setPincode(pincode);
			
			addressDetailsDAO.saveOrUpdate(address);
			
			status="success";
		} 
		catch (Exception e) 
		{
			status="failure";
		}
		
		return status;
	}
	
}
