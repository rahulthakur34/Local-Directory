package com.niit.efashion.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.efashion.model.Payment;

public class PaymentTest {

public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.efashion");
		context.refresh();
		
		Payment payment=(Payment) context.getBean("payment");
		System.out.println("Its working");
	}

	
}
