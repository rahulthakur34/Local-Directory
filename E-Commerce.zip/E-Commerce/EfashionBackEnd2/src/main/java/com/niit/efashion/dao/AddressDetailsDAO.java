package com.niit.efashion.dao;

import com.niit.efashion.model.AddressDetails;

public interface AddressDetailsDAO {

	public void saveOrUpdate(AddressDetails addressDetails);
	
	public void delete(int cartId);
	
	public AddressDetails get(int cartId);
	
}
