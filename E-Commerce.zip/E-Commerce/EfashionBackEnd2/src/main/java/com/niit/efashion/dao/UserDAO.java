package com.niit.efashion.dao;

import java.util.List;

import com.niit.efashion.model.User;

public interface UserDAO {

    public List<User> list();
	
	public User get(String username, String password);
	
	public void saveorupdate(User user);
	
	public void delete(String username);

	public boolean isValidUser(String username, String password);
}
