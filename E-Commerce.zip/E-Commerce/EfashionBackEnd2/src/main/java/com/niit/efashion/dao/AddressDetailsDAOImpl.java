package com.niit.efashion.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.efashion.model.AddressDetails;

@Repository("addressDetailsDAO")
public class AddressDetailsDAOImpl implements AddressDetailsDAO {
	
	@Autowired
	SessionFactory sessionFactory;
	
	public AddressDetailsDAOImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}

	@Transactional
	public void saveOrUpdate(AddressDetails addressDetails) {
		sessionFactory.getCurrentSession().saveOrUpdate(addressDetails);
	}

	@Transactional
	public void delete(int cartId) {
		AddressDetails addressDetails=new AddressDetails();
		addressDetails.setCartId(cartId);
		try {
			sessionFactory.getCurrentSession().delete(addressDetails);
		} 
		catch (Exception e) {
			e.printStackTrace();
			 e.getMessage();
		}
	
	}

	@Transactional
	public AddressDetails get(int cartid) {
		String hql = "from Address where cart_id='"+cartid+"'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<AddressDetails> listProduct = (List<AddressDetails>) query.list();
		
		if (listProduct != null && !listProduct.isEmpty()) {
			return listProduct.get(0);
		}
		
		return null;
	}

}
