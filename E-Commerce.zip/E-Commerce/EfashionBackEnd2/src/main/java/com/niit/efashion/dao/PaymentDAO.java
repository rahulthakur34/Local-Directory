package com.niit.efashion.dao;

import com.niit.efashion.model.Payment;

public interface PaymentDAO {

	public Payment get(String account_number);
	
	public void saveOrUpdate(Payment payment);
	
}
