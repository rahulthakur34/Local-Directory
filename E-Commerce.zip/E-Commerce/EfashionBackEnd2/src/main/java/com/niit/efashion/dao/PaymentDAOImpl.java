package com.niit.efashion.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.efashion.model.Payment;

@Repository("paymentDAO")
public class PaymentDAOImpl implements PaymentDAO {

	@Autowired
	SessionFactory sessionFactory;
	
	public PaymentDAOImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}

	@Transactional
	public Payment get(String account_number) {
		String hql = "from Payment where account_number='"+account_number+"'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<Payment> listPayment = (List<Payment>) query.list();
		
		if (listPayment != null && !listPayment.isEmpty()) {
			return listPayment.get(0);
		}
		return null;
	}

	@Transactional
	public void saveOrUpdate(Payment payment) {
		sessionFactory.getCurrentSession().saveOrUpdate(payment);	
	}

}
