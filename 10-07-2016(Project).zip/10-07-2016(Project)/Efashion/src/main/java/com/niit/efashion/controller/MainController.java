package com.niit.efashion.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.efashion.dao.CategoryDAO;
import com.niit.efashion.dao.UserDetailsDAO;
import com.niit.efashion.model.Category;
import com.niit.efashion.model.Product;
import com.niit.efashion.model.UserDetails;

@Controller
public class MainController {

	@Autowired
	UserDetailsDAO userDetailsDAO;

	@Autowired
	UserDetails userDetails;
	
	@Autowired
	CategoryDAO categoryDAO;
	
	@RequestMapping("/")
	public ModelAndView getLanding() {
		ModelAndView mv = new ModelAndView("index");
		return mv;
	}

	@RequestMapping("/gotolanding")
	public String getLandingPage(Model model) {
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("product", new Product());
		return "landingpage";
	}

	@RequestMapping("/gotologin")
	public String getLoginPage(Model model) {
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("product", new Product());
		return "login";
	}

	@RequestMapping("/gotoregistration")
	public String getRegistrationPage(Model model) {
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("product", new Product());
		return "registration";
	}

	@RequestMapping("/gotoaboutus")
	public String getAboutUsPage(Model model) {
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("product", new Product());
		return "aboutus";
	}

	@RequestMapping("/gotocontactus")
	public String getContactUsPage(Model model) {
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("product", new Product());
		return "contactus";
	}

	@RequestMapping("/register")
	public ModelAndView registerUser(@RequestParam("password") String password,
			@RequestParam("repassword") String repassword, @RequestParam("fullname") String fullname,
			@RequestParam("userid") String userid, @RequestParam("email") String email,
			@RequestParam("mobile") String mobile) {
		ModelAndView mv;
		String message = null;
		if (password.equals(repassword)) {
			userDetails.setUserId(userid);
			userDetails.setFullName(fullname);
			userDetails.setEmail(email);
			userDetails.setPassword(password);
			userDetails.setMobileNo(mobile);
			userDetailsDAO.saveOrUpdate(userDetails);
			mv = new ModelAndView("login");
		} else {
			message = "Passwords does not match";
			mv = new ModelAndView("registration");
		}
		mv.addObject("message", message);
		return mv;
	}

}
