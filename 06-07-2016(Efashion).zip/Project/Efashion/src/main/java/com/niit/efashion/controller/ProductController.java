package com.niit.efashion.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.efashion.dao.CategoryDAO;
import com.niit.efashion.dao.ProductDAO;
import com.niit.efashion.dao.SupplierDAO;
import com.niit.efashion.model.Category;
import com.niit.efashion.model.Product;
import com.niit.efashion.model.Supplier;

@Controller
public class ProductController {

	@Autowired
	ProductDAO productDAO;
	
	@Autowired
	CategoryDAO categoryDAO;
	
	@Autowired
	SupplierDAO supplierDAO;
	
	@RequestMapping(value="/getAllProducts",method=RequestMethod.GET)
	public String listProducts(Model model)
	{
		model.addAttribute("product", new Product());
		model.addAttribute("category", new Category());
		model.addAttribute("supplier", new Supplier());
		model.addAttribute("productList", this.productDAO.list());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("supplierList", this.supplierDAO.list());
		return "product";
	}
	
	@RequestMapping(value="/product/add",method=RequestMethod.POST)
	public String addProduct(@ModelAttribute("product") Product product)
	{
		Category category=categoryDAO.getByName(product.getCategory().getName());
		categoryDAO.saveorupdate(category);
		
		Supplier supplier=supplierDAO.getByName(product.getSupplier().getName());
		supplierDAO.saveorupdate(supplier);
		
		product.setCategory(category);
		product.setSupplier(supplier);
		
		product.setCategory_id(category.getCategoryId());
		product.setSupplier_id(supplier.getSupplierId());
		productDAO.saveorupdate(product);
		
		return "redirect:/getAllProducts";
	}
	
	@RequestMapping("product/remove/{productId}")
	public String removeProduct(@PathVariable("productId") String productId,ModelMap modelMap) throws Exception
	{
		try
		{
			productDAO.delete(productId);
			modelMap.addAttribute("message", "Successfully Removed");
		}
		catch(Exception e)
		{
			modelMap.addAttribute("message", e.getMessage());
			e.printStackTrace();
		}
		return "redirect:/getAllProducts";
	}
	
	@RequestMapping("product/edit/{productId}")
	public String editProduct(@PathVariable("productId") String productId,Model model)
	{
		model.addAttribute("product", this.productDAO.get(productId));
		model.addAttribute("listProduct", this.productDAO.list());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("supplierList", this.supplierDAO.list());
		
		return "product";
	}
	
}