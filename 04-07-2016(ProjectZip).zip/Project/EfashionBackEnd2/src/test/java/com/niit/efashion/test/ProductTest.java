package com.niit.efashion.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.efashion.dao.ProductDAO;
import com.niit.efashion.model.Category;
import com.niit.efashion.model.Product;
import com.niit.efashion.model.Supplier;

public class ProductTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.efashion");
		context.refresh();
		
		ProductDAO productDAO=(ProductDAO) context.getBean("productDAO");
		Product product=(Product)context.getBean("product");
		
		product.setProductId("P001");
		product.setProductName("Samsung Galaxy J7");
		product.setCategoryName("Mobile");
		product.setDescription("Samsung Mobile");
		product.setSupplierName("Big Bazaar");
		product.setPrice("14000.00");
		product.setStock("459");
		
		
		productDAO.saveorupdate(product);
	}

}
