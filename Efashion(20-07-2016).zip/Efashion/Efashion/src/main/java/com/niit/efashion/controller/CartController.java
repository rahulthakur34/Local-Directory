package com.niit.efashion.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.niit.efashion.dao.CartDAO;
import com.niit.efashion.dao.CategoryDAO;
import com.niit.efashion.dao.ProductDAO;
import com.niit.efashion.model.Cart;
import com.niit.efashion.model.Category;
import com.niit.efashion.model.Product;

@Controller
public class CartController {

	@Autowired
	CartDAO cartDAO;

	@Autowired
	ProductDAO productDAO;

	@Autowired
	CategoryDAO categoryDAO;

	@RequestMapping("/addtocart/{id}")
	public String getCart(@PathVariable("id") String id, @RequestParam("quantity") int quantity, Principal principal,
			Model model) {
		Product product = productDAO.get(id);
		String name=principal.getName();
		Cart cart = new Cart();
		cart.setProductName(product.getProductName());
		cart.setPrice(product.getPrice());
		cart.setQuantity(quantity);
		cart.setTotal(quantity * product.getPrice());
		cart.setStatus('N');
		cart.setUserId(name);
		cartDAO.saveOrUpdate(cart);
		model.addAttribute("username", name);
		return "redirect:/mycart";
	}

	@RequestMapping("/mycart")
	public String getmycart(Model model,Principal principal) {
		String name=principal.getName();
		model.addAttribute("cartDetails", this.cartDAO.list());
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("username", name);
		return "welcomeuser";
	}

	@RequestMapping("/cart/delete/{id}")
	public String deletecart(@PathVariable("id") int id,Principal principal, Model model) {
		String name=principal.getName();
		model.addAttribute("username", name);
		cartDAO.delete(id);
		return "redirect:/mycart";
	}

}
