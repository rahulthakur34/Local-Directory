package com.niit.efashion.dao;

import com.niit.efashion.model.Account;

public interface AccountDAO {
	
	public Account get(String id);
	public boolean trasfer(String id, int amount);

}
