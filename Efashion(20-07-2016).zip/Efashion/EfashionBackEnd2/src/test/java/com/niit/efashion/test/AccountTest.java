package com.niit.efashion.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.efashion.dao.AccountDAO;
import com.niit.efashion.model.Account;

public class AccountTest {

	public static void main(String[] args){
	AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
	context.scan("com.niit.efashion");
	context.refresh();
	
	AccountDAO cartDAO=(AccountDAO) context.getBean("accountDAO");
	Account cart=(Account) context.getBean("account");
	System.out.println("Its working");
	}
}
