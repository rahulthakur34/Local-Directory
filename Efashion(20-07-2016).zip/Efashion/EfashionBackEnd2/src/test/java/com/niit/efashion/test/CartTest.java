package com.niit.efashion.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.efashion.dao.CartDAO;
import com.niit.efashion.model.Cart;

public class CartTest {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.efashion");
		context.refresh();
		
		CartDAO cartDAO=(CartDAO) context.getBean("cartDAO");
		Cart cart=(Cart) context.getBean("cart");
		System.out.println("Its working");
	}

}
