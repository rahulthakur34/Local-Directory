package com.niit.efashion.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.efashion.dao.ProductDAO;
import com.niit.efashion.model.Product;


public class ProductTest {

public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.efashion");
		context.refresh();
		
		ProductDAO productDAO=(ProductDAO) context.getBean("productDAO");
		Product product=(Product) context.getBean("product");
		System.out.println("Its working");
	}
	
}
