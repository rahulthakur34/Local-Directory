package com.niit.efashion.dao;

import com.niit.efashion.model.UserDetails;

public interface UserDetailsDAO {

	public void saveOrUpdate(UserDetails userDetails);
	
}
